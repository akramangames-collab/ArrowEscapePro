# Arrow Maze Ultra Dense v5

An ultra-dense arrow-path puzzle rebuild based on the supplied gameplay reference.

## Density targets
- Level 1: 26 pieces
- Level 10: 54 pieces
- Level 20: 90 pieces
- Level 30: 125 pieces
- Level 43: 170 pieces
- Level 60: 185 pieces
- Level 120: 215 pieces
- Level 200: 245 pieces

All 200 levels are deterministic and verified solvable in their guaranteed removal order. Empty outer rows/columns are cropped per level so the maze fills more of the screen.

## Gameplay
- Long straight, L, U and zig-zag arrow paths
- Extra micro-arrows fill gaps to create a much denser maze
- Whole-piece slide-out collision checking
- 3 hearts for blocked taps
- Hint and eraser boosters
- Tutorial, level selection and saved progress
- Smooth removal animation
- AdMob test interstitial and rewarded ads
