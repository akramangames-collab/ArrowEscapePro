plugins { id("com.android.application") }

android {
    namespace = "com.arrowescape.pro"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.arrowescape.pro"
        minSdk = 23
        targetSdk = 36
        versionCode = 6
        versionName = "5.0.0"

        manifestPlaceholders["ADMOB_APP_ID"] = "ca-app-pub-3940256099942544~3347511713"
        buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"ca-app-pub-3940256099942544/1033173712\"")
        buildConfigField("String", "ADMOB_REWARDED_ID", "\"ca-app-pub-3940256099942544/5224354917\"")
    }

    buildFeatures { buildConfig = true }
    packaging { resources.excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*") }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:25.4.0")
}
