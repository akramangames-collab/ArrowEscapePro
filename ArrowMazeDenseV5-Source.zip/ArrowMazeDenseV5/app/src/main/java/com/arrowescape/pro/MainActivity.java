package com.arrowescape.pro;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends Activity implements ArrowGameView.Host {
    private ArrowGameView game;
    private InterstitialAd interstitial;
    private RewardedAd rewarded;
    private int completedSinceAd = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        game = new ArrowGameView(this, this);
        setContentView(game);
        MobileAds.initialize(this, status -> {});
        loadInterstitial();
        loadRewarded();
    }

    private void loadInterstitial() {
        InterstitialAd.load(this, BuildConfig.ADMOB_INTERSTITIAL_ID, new AdRequest.Builder().build(),
            new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(InterstitialAd ad) { interstitial = ad; }
                @Override public void onAdFailedToLoad(LoadAdError e) { interstitial = null; }
            });
    }

    private void loadRewarded() {
        RewardedAd.load(this, BuildConfig.ADMOB_REWARDED_ID, new AdRequest.Builder().build(),
            new RewardedAdLoadCallback() {
                @Override public void onAdLoaded(RewardedAd ad) { rewarded = ad; }
                @Override public void onAdFailedToLoad(LoadAdError e) { rewarded = null; }
            });
    }

    @Override public void onLevelCompleted() {
        completedSinceAd++;
        if (completedSinceAd >= 4 && interstitial != null) {
            completedSinceAd = 0;
            InterstitialAd ad = interstitial;
            interstitial = null;
            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdDismissedFullScreenContent() { loadInterstitial(); }
            });
            ad.show(this);
        }
    }

    @Override public void requestRewardedErase() {
        if (rewarded == null) {
            Toast.makeText(this, "Reward not ready yet", Toast.LENGTH_SHORT).show();
            loadRewarded();
            return;
        }
        RewardedAd ad = rewarded;
        rewarded = null;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { loadRewarded(); }
        });
        ad.show(this, rewardItem -> game.grantEraser());
    }

    @Override public void requestRewardedRevive() {
        if (rewarded == null) {
            Toast.makeText(this, "Reward not ready yet", Toast.LENGTH_SHORT).show();
            loadRewarded();
            return;
        }
        RewardedAd ad = rewarded;
        rewarded = null;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { loadRewarded(); }
        });
        ad.show(this, rewardItem -> game.grantRevive());
    }
}
