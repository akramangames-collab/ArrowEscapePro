package com.arrowescape.pro;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.RectF;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ArrowGameView extends View {
    public interface Host {
        void onLevelCompleted();
        void requestRewardedErase();
        void requestRewardedRevive();
    }

    private static final int MAX_LEVEL = 200;
    private static final int NAVY = Color.rgb(8, 29, 73);
    private static final int BLUE = Color.rgb(47, 149, 235);
    private static final int PALE = Color.rgb(242, 246, 252);
    private static final int DOT = Color.rgb(211, 219, 230);
    private static final int RED = Color.rgb(255, 76, 83);
    private static final int LOST_HEART = Color.rgb(229, 235, 243);
    private static final int TEXT = Color.rgb(20, 24, 31);

    private enum Screen { PLAY, LEVELS }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Host host;
    private final SharedPreferences prefs;
    private final Vibrator vibrator;
    private final ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 58);
    private final Random rng = new Random();
    private final ArrayList<Piece> pieces = new ArrayList<>();
    private String[] packedLevels;

    private Screen screen = Screen.PLAY;
    private int level;
    private int maxUnlocked;
    private int hearts = 3;
    private int hints = 2;
    private int erasers = 1;
    private int gridW = 24, gridH = 30;
    private boolean finished = false;
    private boolean failed = false;
    private boolean tutorial;
    private boolean settingsOpen = false;
    private int levelPage = 0;

    private float boardLeft, boardTop, cell, boardW, boardH;
    private int insetTop = 0, insetBottom = 0;
    private long lastFrame = 0L;
    private long touchRippleUntil = 0L;
    private float rippleX, rippleY;
    private String toast = "";
    private long toastUntil = 0L;

    private static class Piece {
        int id;
        ArrayList<Point> pts = new ArrayList<>();
        int dx, dy;
        HashSet<Long> nodes = new HashSet<>();
        HashSet<Long> edges = new HashSet<>();
        boolean removed = false;
        boolean moving = false;
        float moveT = 0f;
        int moveSteps = 0;
        long flashUntil = 0L;
        long hintUntil = 0L;
    }

    public ArrowGameView(Context context, Host host) {
        super(context);
        this.host = host;
        prefs = context.getSharedPreferences("arrow_puzzle_faithful", Context.MODE_PRIVATE);
        maxUnlocked = Math.max(1, prefs.getInt("maxUnlocked", 1));
        level = Math.min(MAX_LEVEL, Math.max(1, prefs.getInt("lastLevel", 1)));
        tutorial = !prefs.getBoolean("tutorialSeen", false);
        vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        setBackgroundColor(Color.WHITE);
        setFocusable(true);
        loadPackedLevels();
        setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                insetTop = bars.top;
                insetBottom = bars.bottom;
            } else {
                insetTop = insets.getSystemWindowInsetTop();
                insetBottom = insets.getSystemWindowInsetBottom();
            }
            invalidate();
            return insets;
        });
        startLevel(level);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        long now = SystemClock.elapsedRealtime();
        float dt = lastFrame == 0 ? 0f : Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        if (screen == Screen.PLAY) {
            updateAnimations(dt, now);
            drawPlay(c, now);
        } else {
            drawLevels(c);
        }
        if (toastUntil > now) drawToast(c, toast);
        if (touchRippleUntil > now) {
            float t = 1f - (touchRippleUntil - now) / 360f;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(Color.argb((int)(110 * (1f-t)), 150, 164, 184));
            c.drawCircle(rippleX, rippleY, dp(10) + dp(18)*t, paint);
            paint.setStyle(Paint.Style.FILL);
            invalidate();
        }
    }

    private void updateAnimations(float dt, long now) {
        boolean any = false;
        for (Piece p : pieces) {
            if (p.moving && !p.removed) {
                p.moveT += dt / 0.34f;
                if (p.moveT >= 1f) {
                    p.moveT = 1f;
                    p.moving = false;
                    p.removed = true;
                } else any = true;
            }
            if (p.flashUntil > now || p.hintUntil > now) any = true;
        }
        if (!finished && !failed && remaining() == 0) {
            finished = true;
            if (level >= maxUnlocked && level < MAX_LEVEL) {
                maxUnlocked = level + 1;
                prefs.edit().putInt("maxUnlocked", maxUnlocked).apply();
            }
            prefs.edit().putInt("lastLevel", Math.min(MAX_LEVEL, level + 1)).apply();
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 180);
            buzz(70);
            host.onLevelCompleted();
            any = true;
        }
        if (any) invalidate();
    }

    private void drawPlay(Canvas c, long now) {
        final float w = getWidth();
        final float h = getHeight();
        final float top = insetTop + dp(8);

        drawBack(c, dp(28), top + dp(35));
        paint.setColor(TEXT);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(25));
        paint.setFakeBoldText(true);
        c.drawText("Level " + level, w/2f, top + dp(43), paint);
        paint.setFakeBoldText(false);
        drawGear(c, w - dp(31), top + dp(35));

        float statY = top + dp(84);
        pill(c, new RectF(dp(20), statY-dp(25), dp(116), statY+dp(25)), PALE);
        drawMiniArrow(c, dp(40), statY, dp(11), NAVY, -45);
        paint.setColor(Color.rgb(79, 93, 116));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(19));
        paint.setFakeBoldText(true);
        c.drawText(String.valueOf(remaining()), dp(82), statY+dp(7), paint);
        paint.setFakeBoldText(false);

        float hx = w/2f - dp(40);
        for (int i=0;i<3;i++) {
            drawHeart(c, hx + i*dp(40), statY, dp(15), i<hearts ? RED : LOST_HEART);
        }

        RectF diff = new RectF(w-dp(95), statY-dp(25), w-dp(20), statY+dp(25));
        pill(c, diff, PALE);
        paint.setColor(Color.rgb(93, 104, 125));
        paint.setTextSize(dp(14));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setFakeBoldText(true);
        c.drawText(difficulty(), diff.centerX(), diff.centerY()+dp(5), paint);
        paint.setFakeBoldText(false);

        float controlsBottom = h - insetBottom - dp(24);
        float controlR = dp(34);
        float cy = controlsBottom - controlR;
        float cx1 = w/2f - dp(55), cx2 = w/2f + dp(55);

        float boardAreaTop = statY + dp(55);
        float boardAreaBottom = cy - dp(55);
        float availW = w - dp(30);
        float availH = boardAreaBottom - boardAreaTop;
        cell = Math.min(availW / (gridW + 2f), availH / (gridH + 2f));
        cell = Math.max(dp(5.4f), cell);
        boardW = gridW * cell;
        boardH = gridH * cell;
        boardLeft = (w - boardW)/2f;
        boardTop = boardAreaTop + (availH - boardH)/2f;

        drawDottedGrid(c);
        drawPieces(c, now);

        drawRoundControl(c, cx1, cy, controlR);
        drawBulb(c, cx1, cy, dp(17));
        if (hints > 0) {
            paint.setColor(BLUE);
            c.drawCircle(cx1+dp(26), cy-dp(26), dp(14), paint);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(14));
            paint.setFakeBoldText(true);
            c.drawText(String.valueOf(hints), cx1+dp(26), cy-dp(21), paint);
            paint.setFakeBoldText(false);
        }

        drawRoundControl(c, cx2, cy, controlR);
        drawEraser(c, cx2, cy, dp(18));

        if (tutorial) drawTutorial(c);
        else if (settingsOpen) drawSettings(c);
        else if (finished) drawWin(c);
        else if (failed) drawFail(c);
    }

    private void drawDottedGrid(Canvas c) {
        paint.setColor(DOT);
        for (int y=0; y<=gridH; y++) {
            float py = boardTop + y*cell;
            for (int x=0; x<=gridW; x++) {
                c.drawCircle(boardLeft+x*cell, py, Math.max(0.8f, cell*0.045f), paint);
            }
        }
    }

    private void drawPieces(Canvas c, long now) {
        float stroke = Math.max(dp(2.2f), cell*0.12f);
        for (Piece p : pieces) {
            if (p.removed) continue;
            float shift = p.moving ? p.moveT * p.moveSteps * cell : 0f;
            float sx = p.dx*shift, sy = p.dy*shift;
            float shake = 0f;
            if (p.flashUntil > now) shake = (float)Math.sin(now*0.085) * dp(3.5f);
            int col = p.flashUntil > now ? Color.rgb(228, 65, 71) : (p.hintUntil > now ? Color.rgb(236, 167, 28) : NAVY);
            int alpha = p.moving ? Math.max(30, (int)(255*(1f-p.moveT*0.65f))) : 255;
            paint.setColor(Color.argb(alpha, Color.red(col), Color.green(col), Color.blue(col)));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(stroke);
            paint.setStrokeCap(Paint.Cap.SQUARE);
            paint.setStrokeJoin(Paint.Join.ROUND);
            Path path = new Path();
            for (int i=0;i<p.pts.size();i++) {
                Point q=p.pts.get(i);
                float px = boardLeft + q.x*cell + sx + (p.dy!=0?shake:0);
                float py = boardTop + q.y*cell + sy + (p.dx!=0?shake:0);
                if (i==0) path.moveTo(px,py); else path.lineTo(px,py);
            }
            c.drawPath(path, paint);
            paint.setStyle(Paint.Style.FILL);
            drawArrowHead(c,p,sx,sy,shake,col,alpha);
        }
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawArrowHead(Canvas c, Piece p, float sx, float sy, float shake, int col, int alpha) {
        Point tip = p.pts.get(p.pts.size()-1);
        float tx = boardLeft + tip.x*cell + sx + (p.dy!=0?shake:0);
        float ty = boardTop + tip.y*cell + sy + (p.dx!=0?shake:0);
        float s = Math.max(dp(5.5f), cell*0.28f);
        float px = -p.dy, py = p.dx;
        float bx = tx - p.dx*s*1.25f;
        float by = ty - p.dy*s*1.25f;
        Path a = new Path();
        a.moveTo(tx + p.dx*s*0.35f, ty + p.dy*s*0.35f);
        a.lineTo(bx + px*s*0.62f, by + py*s*0.62f);
        a.lineTo(bx - px*s*0.62f, by - py*s*0.62f);
        a.close();
        paint.setColor(Color.argb(alpha,Color.red(col),Color.green(col),Color.blue(col)));
        c.drawPath(a,paint);
    }

    private void drawTutorial(Canvas c) {
        paint.setColor(Color.argb(132, 20, 28, 38));
        c.drawRect(0,0,getWidth(),getHeight(),paint);
        float w=getWidth(), h=getHeight();
        RectF r=new RectF(dp(25),h*0.27f,w-dp(25),h*0.72f);
        paint.setColor(Color.WHITE);
        c.drawRoundRect(r,dp(24),dp(24),paint);
        paint.setColor(TEXT); paint.setTextAlign(Paint.Align.CENTER); paint.setFakeBoldText(true); paint.setTextSize(dp(27));
        c.drawText("How to play",r.centerX(),r.top+dp(48),paint);
        paint.setFakeBoldText(false); paint.setTextSize(dp(16)); paint.setColor(Color.rgb(80,90,105));
        c.drawText("Every line has an arrow at one end.",r.centerX(),r.top+dp(86),paint);
        c.drawText("Tap it only when it can slide out",r.centerX(),r.top+dp(111),paint);
        c.drawText("in the arrow's direction without hitting another line.",r.centerX(),r.top+dp(136),paint);
        c.drawText("A blocked tap costs one heart.",r.centerX(),r.top+dp(171),paint);
        float y=r.top+dp(218);
        paint.setColor(NAVY); paint.setStrokeWidth(dp(4)); paint.setStyle(Paint.Style.STROKE); paint.setStrokeCap(Paint.Cap.SQUARE);
        Path demo=new Path(); demo.moveTo(r.centerX()-dp(70),y+dp(24)); demo.lineTo(r.centerX()-dp(5),y+dp(24)); demo.lineTo(r.centerX()-dp(5),y); demo.lineTo(r.centerX()+dp(65),y); c.drawPath(demo,paint); paint.setStyle(Paint.Style.FILL);
        drawMiniArrow(c,r.centerX()+dp(65),y,dp(12),NAVY,0);
        RectF b=new RectF(r.left+dp(40),r.bottom-dp(68),r.right-dp(40),r.bottom-dp(20));
        paint.setColor(BLUE); c.drawRoundRect(b,dp(24),dp(24),paint);
        paint.setColor(Color.WHITE); paint.setTextSize(dp(17)); paint.setFakeBoldText(true); c.drawText("GOT IT",b.centerX(),b.centerY()+dp(6),paint); paint.setFakeBoldText(false);
    }

    private void drawSettings(Canvas c) {
        paint.setColor(Color.argb(120, 20, 28, 38)); c.drawRect(0,0,getWidth(),getHeight(),paint);
        float w=getWidth(),h=getHeight(); RectF r=new RectF(dp(32),h*.29f,w-dp(32),h*.68f);
        paint.setColor(Color.WHITE); c.drawRoundRect(r,dp(24),dp(24),paint);
        paint.setColor(TEXT);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(dp(25));paint.setFakeBoldText(true);c.drawText("Settings",r.centerX(),r.top+dp(48),paint);paint.setFakeBoldText(false);
        paint.setTextSize(dp(16));paint.setColor(Color.rgb(70,82,100));
        c.drawText("Sound and vibration are enabled",r.centerX(),r.top+dp(92),paint);
        RectF restart=new RectF(r.left+dp(36),r.top+dp(125),r.right-dp(36),r.top+dp(175));
        paint.setColor(PALE);c.drawRoundRect(restart,dp(22),dp(22),paint);paint.setColor(TEXT);paint.setFakeBoldText(true);c.drawText("Restart level",restart.centerX(),restart.centerY()+dp(6),paint);paint.setFakeBoldText(false);
        RectF close=new RectF(r.left+dp(36),r.bottom-dp(70),r.right-dp(36),r.bottom-dp(20));
        paint.setColor(BLUE);c.drawRoundRect(close,dp(22),dp(22),paint);paint.setColor(Color.WHITE);paint.setFakeBoldText(true);c.drawText("Close",close.centerX(),close.centerY()+dp(6),paint);paint.setFakeBoldText(false);
    }

    private void drawWin(Canvas c) {
        float w=getWidth(),h=getHeight();
        paint.setColor(Color.rgb(19,157,239)); c.drawRect(0,0,w,h,paint);
        paint.setColor(Color.argb(50,255,255,255));
        for(int i=0;i<24;i++){
            double a=Math.PI*2*i/24.0; Path ray=new Path(); ray.moveTo(w/2f,h*.43f); ray.lineTo((float)(w/2+Math.cos(a)*w),(float)(h*.43+Math.sin(a)*h)); ray.lineTo((float)(w/2+Math.cos(a+.08)*w),(float)(h*.43+Math.sin(a+.08)*h)); ray.close(); c.drawPath(ray,paint);
        }
        paint.setTextAlign(Paint.Align.CENTER);paint.setColor(Color.WHITE);paint.setFakeBoldText(true);paint.setTextSize(dp(31));c.drawText("Puzzle Cleared!",w/2f,h*.29f,paint);
        paint.setTextSize(dp(20));c.drawText("Level " + level + " completed",w/2f,h*.35f,paint);paint.setFakeBoldText(false);
        RectF card=new RectF(w*.22f,h*.40f,w*.78f,h*.65f);paint.setColor(Color.WHITE);c.drawRoundRect(card,dp(12),dp(12),paint);
        paint.setColor(NAVY);paint.setTextSize(dp(54));c.drawText("↗",card.centerX(),card.centerY()+dp(18),paint);
        RectF next=new RectF(w*.18f,h*.72f,w*.82f,h*.78f);paint.setColor(Color.WHITE);c.drawRoundRect(next,dp(26),dp(26),paint);paint.setColor(BLUE);paint.setFakeBoldText(true);paint.setTextSize(dp(16));c.drawText(level<MAX_LEVEL?"NEXT LEVEL":"LEVELS",next.centerX(),next.centerY()+dp(6),paint);paint.setFakeBoldText(false);
        paint.setColor(Color.WHITE);paint.setTextSize(dp(15));c.drawText("Levels",w/2f,h*.84f,paint);
    }

    private void drawFail(Canvas c) {
        paint.setColor(Color.argb(125,20,28,38));c.drawRect(0,0,getWidth(),getHeight(),paint);
        float w=getWidth(),h=getHeight();RectF r=new RectF(dp(30),h*.34f,w-dp(30),h*.70f);paint.setColor(Color.WHITE);c.drawRoundRect(r,dp(24),dp(24),paint);
        paint.setTextAlign(Paint.Align.CENTER);paint.setColor(TEXT);paint.setFakeBoldText(true);paint.setTextSize(dp(28));c.drawText("No hearts left",r.centerX(),r.top+dp(55),paint);paint.setFakeBoldText(false);paint.setTextSize(dp(16));paint.setColor(Color.rgb(87,96,112));c.drawText("Restart or watch a rewarded ad to continue.",r.centerX(),r.top+dp(92),paint);
        RectF b1=new RectF(r.left+dp(30),r.top+dp(125),r.right-dp(30),r.top+dp(177));paint.setColor(BLUE);c.drawRoundRect(b1,dp(24),dp(24),paint);paint.setColor(Color.WHITE);paint.setFakeBoldText(true);c.drawText("RESTART",b1.centerX(),b1.centerY()+dp(6),paint);
        RectF b2=new RectF(r.left+dp(30),r.top+dp(192),r.right-dp(30),r.top+dp(244));paint.setColor(PALE);c.drawRoundRect(b2,dp(24),dp(24),paint);paint.setColor(TEXT);c.drawText("WATCH AD + REVIVE",b2.centerX(),b2.centerY()+dp(6),paint);paint.setFakeBoldText(false);
    }

    private void drawLevels(Canvas c) {
        float w=getWidth(),h=getHeight(),top=insetTop+dp(12);
        paint.setColor(TEXT);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(dp(27));paint.setFakeBoldText(true);c.drawText("Levels",w/2,top+dp(35),paint);paint.setFakeBoldText(false);
        drawBack(c,dp(28),top+dp(28));
        int start=levelPage*20+1;
        float gap=dp(10), left=dp(20), bw=(w-left*2-gap*3)/4f, bh=dp(62), y0=top+dp(78);
        for(int i=0;i<20;i++){
            int lv=start+i;if(lv>MAX_LEVEL)break;int col=i%4,row=i/4;RectF r=new RectF(left+col*(bw+gap),y0+row*(bh+gap),left+col*(bw+gap)+bw,y0+row*(bh+gap)+bh);
            boolean open=lv<=maxUnlocked;paint.setColor(open?(lv==level?Color.rgb(223,240,255):PALE):Color.rgb(244,246,249));c.drawRoundRect(r,dp(16),dp(16),paint);paint.setTextAlign(Paint.Align.CENTER);paint.setFakeBoldText(true);paint.setTextSize(dp(18));paint.setColor(open?TEXT:Color.rgb(171,180,194));c.drawText(open?String.valueOf(lv):"•",r.centerX(),r.centerY()+dp(6),paint);paint.setFakeBoldText(false);
        }
        float y=h-insetBottom-dp(72);RectF prev=new RectF(dp(24),y,w*.45f,y+dp(48));RectF next=new RectF(w*.55f,y,w-dp(24),y+dp(48));
        paint.setColor(PALE);c.drawRoundRect(prev,dp(22),dp(22),paint);c.drawRoundRect(next,dp(22),dp(22),paint);paint.setColor(TEXT);paint.setTextSize(dp(15));paint.setFakeBoldText(true);c.drawText("‹ PREV",prev.centerX(),prev.centerY()+dp(5),paint);c.drawText("NEXT ›",next.centerX(),next.centerY()+dp(5),paint);paint.setFakeBoldText(false);
    }

    private void drawBack(Canvas c,float x,float y){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(3.5f));paint.setStrokeCap(Paint.Cap.ROUND);paint.setColor(BLUE);Path p=new Path();p.moveTo(x+dp(8),y-dp(13));p.lineTo(x-dp(5),y);p.lineTo(x+dp(8),y+dp(13));c.drawPath(p,paint);paint.setStyle(Paint.Style.FILL);}

    private void drawGear(Canvas c,float x,float y){paint.setColor(BLUE);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(3));c.drawCircle(x,y,dp(10),paint);c.drawCircle(x,y,dp(4),paint);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=(float)(x+Math.cos(a)*dp(12)),y1=(float)(y+Math.sin(a)*dp(12));float x2=(float)(x+Math.cos(a)*dp(16)),y2=(float)(y+Math.sin(a)*dp(16));c.drawLine(x1,y1,x2,y2,paint);}paint.setStyle(Paint.Style.FILL);}

    private void drawHeart(Canvas c,float x,float y,float s,int color){Path p=new Path();p.moveTo(x,y+s*.9f);p.cubicTo(x-s*1.25f,y+s*.1f,x-s*1.15f,y-s*.75f,x-s*.55f,y-s*.85f);p.cubicTo(x-s*.1f,y-s*.95f,x,y-s*.55f,x,y-s*.35f);p.cubicTo(x,y-s*.55f,x+s*.1f,y-s*.95f,x+s*.55f,y-s*.85f);p.cubicTo(x+s*1.15f,y-s*.75f,x+s*1.25f,y+s*.1f,x,y+s*.9f);p.close();paint.setColor(color);c.drawPath(p,paint);}

    private void pill(Canvas c,RectF r,int color){paint.setColor(color);c.drawRoundRect(r,dp(16),dp(16),paint);}

    private void drawRoundControl(Canvas c,float x,float y,float r){paint.setColor(Color.rgb(239,243,248));c.drawCircle(x,y,r+dp(3),paint);paint.setColor(Color.WHITE);c.drawCircle(x,y,r,paint);}

    private void drawBulb(Canvas c,float x,float y,float s){paint.setColor(Color.rgb(255,193,30));c.drawCircle(x,y-s*.25f,s*.62f,paint);paint.setColor(Color.rgb(255,218,72));c.drawCircle(x-s*.2f,y-s*.45f,s*.2f,paint);paint.setColor(Color.rgb(139,157,191));RectF base=new RectF(x-s*.35f,y+s*.30f,x+s*.35f,y+s*.82f);c.drawRoundRect(base,s*.13f,s*.13f,paint);paint.setColor(Color.rgb(95,113,151));c.drawRect(x-s*.28f,y+s*.62f,x+s*.28f,y+s*.78f,paint);}

    private void drawEraser(Canvas c,float x,float y,float s){c.save();c.rotate(-28,x,y);RectF body=new RectF(x-s*.55f,y-s*.82f,x+s*.55f,y+s*.82f);paint.setColor(Color.rgb(107,82,224));c.drawRoundRect(body,s*.18f,s*.18f,paint);RectF stripe=new RectF(body.left+s*.12f,body.top+s*.23f,body.right-s*.12f,body.top+s*.42f);paint.setColor(Color.rgb(159,140,244));c.drawRoundRect(stripe,s*.08f,s*.08f,paint);paint.setColor(Color.rgb(229,232,245));c.drawRoundRect(new RectF(body.left,body.bottom-s*.23f,body.right,body.bottom),s*.12f,s*.12f,paint);c.restore();}

    private void drawMiniArrow(Canvas c,float x,float y,float s,int color,float degrees){c.save();c.rotate(degrees,x,y);paint.setColor(color);Path a=new Path();a.moveTo(x+s*.7f,y);a.lineTo(x-s*.35f,y-s*.45f);a.lineTo(x-s*.18f,y);a.lineTo(x-s*.35f,y+s*.45f);a.close();c.drawPath(a,paint);c.restore();}

    private void drawToast(Canvas c,String msg){paint.setTextSize(dp(14));paint.setTextAlign(Paint.Align.CENTER);float tw=paint.measureText(msg);RectF r=new RectF((getWidth()-tw)/2-dp(18),insetTop+dp(130),(getWidth()+tw)/2+dp(18),insetTop+dp(172));paint.setColor(Color.argb(225,31,38,50));c.drawRoundRect(r,dp(20),dp(20),paint);paint.setColor(Color.WHITE);c.drawText(msg,r.centerX(),r.centerY()+dp(5),paint);}

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction()!=MotionEvent.ACTION_UP) return true;
        float x=e.getX(), y=e.getY();
        rippleX=x; rippleY=y; touchRippleUntil=SystemClock.elapsedRealtime()+360; invalidate();
        if (screen==Screen.LEVELS) return handleLevelsTouch(x,y);
        if (tutorial) {
            if (y>getHeight()*.60f) {
                tutorial=false; prefs.edit().putBoolean("tutorialSeen",true).apply(); invalidate();
            }
            return true;
        }
        if (settingsOpen) {
            float h=getHeight(),w=getWidth();
            if (y>h*.29f+dp(120)&&y<h*.29f+dp(190)) startLevel(level);
            else if (y>h*.58f) { settingsOpen=false; invalidate(); }
            return true;
        }
        if (finished) {
            float h=getHeight();
            if (y>h*.69f&&y<h*.81f) { if(level<MAX_LEVEL) startLevel(level+1); else {screen=Screen.LEVELS;levelPage=(level-1)/20;invalidate();} }
            else if (y>h*.80f) {screen=Screen.LEVELS;levelPage=(level-1)/20;invalidate();}
            return true;
        }
        if (failed) {
            float h=getHeight();
            if (y>h*.46f&&y<h*.58f) startLevel(level);
            else if (y>h*.58f&&y<h*.72f) host.requestRewardedRevive();
            return true;
        }
        float top=insetTop+dp(8);
        if (x<dp(70)&&y<top+dp(70)) {screen=Screen.LEVELS;levelPage=(level-1)/20;invalidate();return true;}
        if (x>getWidth()-dp(75)&&y<top+dp(70)) {settingsOpen=true;invalidate();return true;}
        float controlsBottom=getHeight()-insetBottom-dp(24), cy=controlsBottom-dp(34), cx1=getWidth()/2f-dp(55), cx2=getWidth()/2f+dp(55);
        if (dist(x,y,cx1,cy)<dp(45)) {useHint();return true;}
        if (dist(x,y,cx2,cy)<dp(45)) {useEraser();return true;}
        Piece p=findPieceAt(x,y);
        if (p!=null) tapPiece(p);
        return true;
    }

    private boolean handleLevelsTouch(float x,float y){float w=getWidth(),h=getHeight(),top=insetTop+dp(12);if(x<dp(70)&&y<top+dp(65)){screen=Screen.PLAY;invalidate();return true;}float gap=dp(10),left=dp(20),bw=(w-left*2-gap*3)/4f,bh=dp(62),y0=top+dp(78);if(y>=y0&&y<y0+5*(bh+gap)){int col=(int)((x-left)/(bw+gap)),row=(int)((y-y0)/(bh+gap));if(col>=0&&col<4&&row>=0&&row<5){int lv=levelPage*20+row*4+col+1;if(lv<=maxUnlocked&&lv<=MAX_LEVEL){startLevel(lv);return true;}}}if(y>h-insetBottom-dp(90)){if(x<w/2&&levelPage>0)levelPage--;else if(x>=w/2&&levelPage<9)levelPage++;invalidate();}return true;}

    private Piece findPieceAt(float x,float y){Piece best=null;float bestD=Math.max(dp(16),cell*.42f);for(Piece p:pieces){if(p.removed||p.moving)continue;for(int i=0;i<p.pts.size()-1;i++){Point a=p.pts.get(i),b=p.pts.get(i+1);float ax=boardLeft+a.x*cell,ay=boardTop+a.y*cell,bx=boardLeft+b.x*cell,by=boardTop+b.y*cell;float d=pointSegDist(x,y,ax,ay,bx,by);if(d<bestD){bestD=d;best=p;}}}return best;}

    private float pointSegDist(float px,float py,float ax,float ay,float bx,float by){float vx=bx-ax,vy=by-ay,wx=px-ax,wy=py-ay;float c1=vx*wx+vy*wy;if(c1<=0)return dist(px,py,ax,ay);float c2=vx*vx+vy*vy;if(c2<=c1)return dist(px,py,bx,by);float t=c1/c2;return dist(px,py,ax+t*vx,ay+t*vy);}
    private float dist(float x1,float y1,float x2,float y2){float dx=x1-x2,dy=y1-y2;return (float)Math.sqrt(dx*dx+dy*dy);}

    private void tapPiece(Piece p){if(isClear(p)){p.moving=true;p.moveT=0;p.moveSteps=exitSteps(p);tone.startTone(ToneGenerator.TONE_PROP_BEEP,70);buzz(20);}else{p.flashUntil=SystemClock.elapsedRealtime()+390;hearts--;tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,110);buzz(55);showToast("Blocked path");if(hearts<=0)failed=true;}invalidate();}

    private void useHint(){if(hints<=0){showToast("No hints left");return;}ArrayList<Piece> safe=new ArrayList<>();for(Piece p:pieces)if(!p.removed&&!p.moving&&isClear(p))safe.add(p);if(safe.isEmpty()){showToast("No safe arrow found");return;}hints--;Piece p=safe.get(rng.nextInt(safe.size()));p.hintUntil=SystemClock.elapsedRealtime()+1600;showToast("Safe arrow highlighted");invalidate();}

    private void useEraser(){if(erasers<=0){host.requestRewardedErase();return;}ArrayList<Piece> active=new ArrayList<>();for(Piece p:pieces)if(!p.removed&&!p.moving)active.add(p);if(active.isEmpty())return;Piece p=active.get(rng.nextInt(active.size()));erasers--;p.moving=true;p.moveT=0;p.moveSteps=exitSteps(p);showToast("One arrow removed");invalidate();}

    public void grantEraser(){erasers++;showToast("Eraser added");invalidate();}
    public void grantRevive(){if(!failed)return;failed=false;hearts=2;showToast("Revived with 2 hearts");invalidate();}

    private int remaining(){int n=0;for(Piece p:pieces)if(!p.removed)n++;return n;}
    private String difficulty(){if(level<=12)return "Easy";if(level<=30)return "Medium";if(level<=120)return "Hard";return "Expert";}

    private void startLevel(int lv){level=Math.max(1,Math.min(MAX_LEVEL,lv));prefs.edit().putInt("lastLevel",level).apply();screen=Screen.PLAY;settingsOpen=false;finished=false;failed=false;hearts=3;hints=2;erasers=1;generateLevel(level);invalidate();}

    private void loadPackedLevels(){
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(getContext().getAssets().open("levels.txt")));
            ArrayList<String> lines = new ArrayList<>();
            String line;
            while ((line = br.readLine()) != null) if (!line.trim().isEmpty()) lines.add(line.trim());
            br.close();
            packedLevels = lines.toArray(new String[0]);
        } catch (Exception ignored) {
            packedLevels = null;
        }
    }

    private void generateLevel(int lv){
        if (packedLevels != null && lv >= 1 && lv <= packedLevels.length) {
            try {
                String line = packedLevels[lv-1];
                String[] half = line.split("\\|", 2);
                String[] dims = half[0].split(",");
                gridW = Integer.parseInt(dims[0]);
                gridH = Integer.parseInt(dims[1]);
                pieces.clear();
                if (half.length > 1 && !half[1].isEmpty()) {
                    String[] defs = half[1].split(";");
                    for (int i=0; i<defs.length; i++) {
                        String[] v = defs[i].split(",");
                        if (v.length < 6) continue;
                        Piece p = new Piece();
                        p.id = i;
                        p.dx = Integer.parseInt(v[0]);
                        p.dy = Integer.parseInt(v[1]);
                        for (int k=2; k+1<v.length; k+=2) {
                            p.pts.add(new Point(Integer.parseInt(v[k]), Integer.parseInt(v[k+1])));
                        }
                        rebuildOccupancy(p);
                        pieces.add(p);
                    }
                }
                return;
            } catch (Exception ignored) { }
        }
        generateFallbackLevel(lv);
    }

    private void generateFallbackLevel(int lv){
        if(lv<=20){gridW=18;gridH=24;}else if(lv<=60){gridW=24;gridH=30;}else if(lv<=120){gridW=28;gridH=34;}else{gridW=30;gridH=36;}
        int target;
        if(lv<=43) target=Math.min(72,Math.round(12+lv*1.4f));
        else target=Math.min(100,72+(lv-43)/4);
        target=Math.max(12,target);
        rng.setSeed(0x5A17BEEFL + lv*104729L);
        pieces.clear();
        HashSet<Long> occupiedNodes=new HashSet<>();
        HashSet<Long> occupiedEdges=new HashSet<>();
        for(int i=0;i<target;i++){
            Piece chosen=null;
            int attempts=0;
            while(attempts++<2800){
                Piece cand=randomPiece(i);
                if(cand==null)continue;
                if(intersects(cand,occupiedNodes,occupiedEdges,0))continue;
                if(clearAgainst(cand,occupiedNodes,occupiedEdges)) {chosen=cand;break;}
            }
            if(chosen==null) break;
            pieces.add(chosen);
            occupiedNodes.addAll(chosen.nodes); occupiedEdges.addAll(chosen.edges);
        }
        Collections.reverse(pieces);
        for(int i=0;i<pieces.size();i++)pieces.get(i).id=i;
    }

    private Piece randomPiece(int id){
        int[] dxs={1,-1,0,0}, dys={0,0,1,-1};
        int d=rng.nextInt(4),fdx=dxs[d],fdy=dys[d];
        int tipX=1+rng.nextInt(Math.max(1,gridW-1));
        int tipY=1+rng.nextInt(Math.max(1,gridH-1));
        ArrayList<Point> rev=new ArrayList<>();
        int cx=tipX,cy=tipY;rev.add(new Point(cx,cy));
        int backX=-fdx,backY=-fdy;
        int len=1+rng.nextInt(3);cx+=backX*len;cy+=backY*len;rev.add(new Point(cx,cy));
        int segs=1+weightedSegments();
        int pdx=backX,pdy=backY;
        for(int s=1;s<segs;s++){
            int ndx,ndy;
            if(pdx!=0){ndx=0;ndy=rng.nextBoolean()?1:-1;}else{ndy=0;ndx=rng.nextBoolean()?1:-1;}
            len=1+rng.nextInt(3);cx+=ndx*len;cy+=ndy*len;rev.add(new Point(cx,cy));pdx=ndx;pdy=ndy;
        }
        for(Point q:rev)if(q.x<0||q.x>gridW||q.y<0||q.y>gridH)return null;
        Collections.reverse(rev);
        Piece p=new Piece();p.id=id;p.dx=fdx;p.dy=fdy;p.pts=rev;
        rebuildOccupancy(p);
        int expected=1;for(int i=0;i<p.pts.size()-1;i++){Point a=p.pts.get(i),b=p.pts.get(i+1);expected+=Math.abs(b.x-a.x)+Math.abs(b.y-a.y);}if(p.nodes.size()!=expected)return null;
        return p;
    }

    private int weightedSegments(){int v=rng.nextInt(100);if(v<20)return 0;if(v<60)return 1;if(v<88)return 2;return 3;}

    private void rebuildOccupancy(Piece p){p.nodes.clear();p.edges.clear();for(Point q:p.pts)p.nodes.add(nodeKey(q.x,q.y));for(int i=0;i<p.pts.size()-1;i++){Point a=p.pts.get(i),b=p.pts.get(i+1);int dx=Integer.compare(b.x,a.x),dy=Integer.compare(b.y,a.y);int x=a.x,y=a.y;while(x!=b.x||y!=b.y){int nx=x+dx,ny=y+dy;p.nodes.add(nodeKey(nx,ny));if(dx!=0)p.edges.add(edgeKey(Math.min(x,nx),y,1));else p.edges.add(edgeKey(x,Math.min(y,ny),2));x=nx;y=ny;}}}

    private boolean intersects(Piece p,HashSet<Long> nodes,HashSet<Long> edges,int shift){for(long n:p.nodes){int x=nodeX(n)+p.dx*shift,y=nodeY(n)+p.dy*shift;if(nodes.contains(nodeKey(x,y)))return true;}for(long e:p.edges){int x=edgeX(e)+p.dx*shift;int y=edgeY(e)+p.dy*shift;int intOri=(int)(e&3);if(edges.contains(edgeKey(x,y,intOri)))return true;}return false;}

    private boolean clearAgainst(Piece p,HashSet<Long> nodes,HashSet<Long> edges){int max=gridW+gridH+12;for(int k=1;k<=max;k++){if(intersects(p,nodes,edges,k))return false;if(allOutside(p,k))return true;}return false;}

    private boolean allOutside(Piece p,int k){for(Point q:p.pts){int x=q.x+p.dx*k,y=q.y+p.dy*k;if(x>=0&&x<=gridW&&y>=0&&y<=gridH)return false;}return true;}

    private int exitSteps(Piece p){for(int k=1;k<gridW+gridH+20;k++)if(allOutside(p,k))return k+1;return gridW+gridH;}

    private boolean isClear(Piece target){HashSet<Long> nodes=new HashSet<>(),edges=new HashSet<>();for(Piece p:pieces){if(p==target||p.removed||p.moving)continue;nodes.addAll(p.nodes);edges.addAll(p.edges);}return clearAgainst(target,nodes,edges);}

    private long nodeKey(int x,int y){return (((long)(x+128)&0xFFFFL)<<16)|((long)(y+128)&0xFFFFL);}
    private int nodeX(long key){return (int)((key>>>16)&0xFFFFL)-128;}
    private int nodeY(long key){return (int)(key&0xFFFFL)-128;}
    private long edgeKey(int x,int y,int o){return (((long)(x+128)&0xFFFFL)<<20)|(((long)(y+128)&0xFFFFL)<<4)|(o&3);}
    private int edgeX(long key){return (int)((key>>>20)&0xFFFFL)-128;}
    private int edgeY(long key){return (int)((key>>>4)&0xFFFFL)-128;}

    private void showToast(String s){toast=s;toastUntil=SystemClock.elapsedRealtime()+1200;invalidate();}
    private void buzz(long ms){try{if(vibrator==null)return;if(Build.VERSION.SDK_INT>=26)vibrator.vibrate(VibrationEffect.createOneShot(ms,80));else vibrator.vibrate(ms);}catch(Exception ignored){}}
}
